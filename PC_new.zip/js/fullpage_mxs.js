$(function () {
  $('#dowebok').fullpage({
    // sectionsColor: ['#1bbc9b', '#4BBFC3', '#7BAABE', '#f90'],
    easing: 'easeInOutCubic',
    easingcss3: 'ease',
    loopBottom: false
  })


  
})

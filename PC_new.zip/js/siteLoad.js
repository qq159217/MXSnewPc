$(function () {



  // 公共頁面加載
  $('#top').load('../common/common.html')

  // 返回首页
  $('#returnHomepage').click(function () {
    window.location.replace('../../index.html')
  })

  // 表單提交


})

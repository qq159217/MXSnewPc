$(function () {
  $('nav>ul .item').mouseenter(function () {
    $(this).find('.sub-menu').show()
    $(this).siblings().find('.sub-menu').hide()
  })
  // 公共頁面加載
  $('#top').load('../common/common.html')

  $('#marquee2').slide({
    scrollLen: 1,
    effect: 'scrollx',
    auto: true,
    seamless: true,
    interval: 1000,
    lazyload: true

  })

  // 加盟注册表单提交
  $('#joinSubmit').click(function () {
    function p (s) {
      return s < 10 ? '0' + s : s
    }

    function GetNowTime () {
      var myDate = new Date()
      // 获取当前年
      var year = myDate.getFullYear()
      var month = myDate.getMonth() + 1
      var date = myDate.getDate()
      var h = myDate.getHours()
      var m = myDate.getMinutes()
      var s = myDate.getSeconds()
      return year + '-' + p(month) + '-' + p(date) + ' ' + p(h) + ':' + p(m) + ':' + p(s)
    }
    let requireData = $.md5('mixiusi' + GetNowTime())
    $('#hide').attr('value', requireData)

    let newData = $('#joinForm').serialize()
    console.log(newData)
    $.ajax({
      type: 'POST',
      url: 'http://47.98.164.44:8081/joinUs/addJoiner',
      data: newData,
      success: function (result) {
        alert('成功')
      /* if (result.resultCode == 0000) {
        window.location.href = "../site/submit_success/submitSucseccfully.html"
      }; */
      }
    })
  })

  $('.messageR').click(function () {
    console.log('test')
  })
})
